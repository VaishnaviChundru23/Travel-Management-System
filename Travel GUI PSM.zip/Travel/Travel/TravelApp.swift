//
//  TravelApp.swift
//  Travel
//
//  Created by Gaurav Bhambhani on 11/4/24.
//

import SwiftUI

@main
struct TravelApp: App {
    var body: some Scene {
        WindowGroup {
            LandingView()
        }
    }
}
