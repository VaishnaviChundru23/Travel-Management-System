//
//  HomeView.swift
//  Travel
//
//  Created by Gaurav Bhambhani on 11/4/24.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        NavigationStack {
            VStack {
                
            }
            .navigationTitle("Home")
        }
    }
}

#Preview {
    HomeView()
}
